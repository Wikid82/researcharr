"""Media plugins package (examples).

This directory contains media-related plugin examples such as Radarr and
Sonarr. These files are discovered by the PluginRegistry.
"""
