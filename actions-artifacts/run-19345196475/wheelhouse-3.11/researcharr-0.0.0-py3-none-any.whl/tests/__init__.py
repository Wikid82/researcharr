"""Test package marker to support plugin-style imports."""

# This file marks the directory as a Python package.
