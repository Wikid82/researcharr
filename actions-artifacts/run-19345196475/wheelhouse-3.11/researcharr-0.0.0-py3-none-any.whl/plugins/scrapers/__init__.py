"""Scrapers plugins package (examples).

Contains scrapers like Prowlarr.
"""
